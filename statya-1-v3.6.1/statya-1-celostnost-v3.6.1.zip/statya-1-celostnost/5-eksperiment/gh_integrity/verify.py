"""Проверка воспроизводимости (версия 3.6.1).

    python -m gh_integrity.verify --write          # записать results/SHA256SUMS (авторы)
    python -m gh_integrity.verify                  # сверить results/ и data/ с SHA256SUMS
    python -m gh_integrity.verify --dir ПАПКА      # сверить другую копию результатов

Для каждого файла results/ и data/ хранится SHA-256. summary.json сверяется без полей, которые
законно различаются между запусками: время прогона (runtime_s) и версии окружения (environment).
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MANIFEST = ROOT / "results" / "SHA256SUMS"
VOLATILE = ("runtime_s", "environment")


def _digest(path: Path) -> str:
    if path.name == "summary.json":
        d = json.loads(path.read_text(encoding="utf-8"))
        for k in VOLATILE:
            d.pop(k, None)
        data = json.dumps(d, ensure_ascii=False, sort_keys=True).encode("utf-8")
    else:
        data = path.read_bytes()
    return hashlib.sha256(data).hexdigest()


def _files(results: Path, data: Path) -> dict[str, Path]:
    out = {}
    for base, prefix in ((results, "results"), (data, "data")):
        for p in sorted(base.glob("*")):
            if p.is_file() and p.name != "SHA256SUMS":
                out[f"{prefix}/{p.name}"] = p
    return out


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--write", action="store_true", help="записать манифест по results/ и data/")
    ap.add_argument("--dir", type=Path, default=None,
                    help="папка проверяемых результатов (по умолчанию results/; data/ рядом с ней "
                         "или внутри неё)")
    a = ap.parse_args(argv)
    if a.write:
        files = _files(ROOT / "results", ROOT / "data")
        MANIFEST.write_text("".join(f"{_digest(p)}  {k}\n" for k, p in files.items()),
                            encoding="utf-8")
        print(f"записано {len(files)} файлов в {MANIFEST.relative_to(ROOT)}")
        return 0
    res = (a.dir or ROOT / "results").resolve()
    data = res / "data" if (res / "data").is_dir() else res.parent / "data"
    files = _files(res, data)
    expected = dict(reversed(line.split("  ", 1)) for line in
                    MANIFEST.read_text(encoding="utf-8").splitlines() if line.strip())
    bad = 0
    for k, h in expected.items():
        p = files.get(k.strip())
        if p is None:
            print(f"НЕТ ФАЙЛА   {k}")
            bad += 1
        elif _digest(p) != h:
            print(f"ОТЛИЧАЕТСЯ  {k}")
            bad += 1
        else:
            print(f"совпадает   {k}")
    print("ИТОГ:", "все файлы совпадают" if not bad else f"расхождений: {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
